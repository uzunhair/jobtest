// Bootstrap

// import Alert from 'bootstrap/js/dist/alert';
// import Button from 'bootstrap/js/dist/button';
// import Carousel from 'bootstrap/js/dist/carousel';
// import Collapse from 'bootstrap/js/dist/collapse';
// import Dropdown from 'bootstrap/js/dist/dropdown';
// import Modal from 'bootstrap/js/dist/modal';
// import Scrollspy from 'bootstrap/js/dist/scrollspy';
// import Tab from 'bootstrap/js/dist/tab';
// import Tooltip from 'bootstrap/js/dist/tooltip';
// import Popover from 'bootstrap/js/dist/popover';
// import Toast from 'bootstrap/js/dist/toast';

// import { Alert, Button, Carousel, Collapse, Dropdown, Modal, Scrollspy, Tab, Tooltip, Popover, Toast } from 'bootstrap';

// Bem
// require('../blocks/components/_components');
// require('../blocks/modules/_modules');
// require('../blocks/sections/_sections');
// require('../blocks/pages/_pages');

require('./setting');
